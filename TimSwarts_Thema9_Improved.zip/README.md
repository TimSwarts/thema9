# Thema 9 Report and Log
This repo contains the log and full report of the thema9 breast cancer research project, along with all needed data to run the code in the various .Rmd files.
